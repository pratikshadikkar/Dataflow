"""
PDF to Vector Search Pipeline with Custom Semantic Chunking
Uses Vertex AI directly - no LangChain dependency conflicts
"""
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions, StandardOptions, WorkerOptions
from google.cloud import storage, aiplatform
from vertexai.language_models import TextEmbeddingModel
import PyPDF2
import io
import json
import logging
import hashlib
import string
import random
from apache_beam import pvalue
from typing import List, Dict, Any, Optional
from datetime import datetime, UTC
import argparse
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
logging.basicConfig(level=logging.INFO)

class PDFReader(beam.DoFn):
    """Read PDF from GCS and extract text with metadata"""
    
    def __init__(self, project_id: str):
        self.project_id = project_id
        print("Project init")
    
    def setup(self):
        import subprocess
        self.storage_client = storage.Client(project=self.project_id)
        print("GCS Setup")
    
    def process(self, file_path: str):
        try:
            bucket_name = file_path.replace('gs://', '').split('/')[0]
            blob_name = '/'.join(file_path.replace('gs://', '').split('/')[1:])
            print(blob_name)
            logging.info(f"Processing PDF: {file_path}")
            print("PDF processing started")
            
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            pdf_bytes = blob.download_as_bytes()
            
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_bytes))
            pdf_info = pdf_reader.metadata if pdf_reader.metadata else {}
            
            pages_content = []
            full_text = []
            
            for page_num, page in enumerate(pdf_reader.pages):
                page_text = page.extract_text()
                if page_text and page_text.strip():
                    pages_content.append({
                        'page_number': page_num + 1,
                        'text': page_text.strip(),
                        'char_count': len(page_text)
                    })
                    full_text.append(page_text.strip())
            
            combined_text = '\n\n'.join(full_text)
            doc_hash = hashlib.md5(pdf_bytes).hexdigest()
            
            document_data = {
                'file_path': file_path,
                'file_name': blob_name.split('/')[-1],
                'bucket_name': bucket_name,
                'blob_name': blob_name,
                'document_hash': doc_hash,
                'total_pages': len(pdf_reader.pages),
                'extracted_pages': len(pages_content),
                'pages_content': pages_content,
                'full_text': combined_text,
                'processing_timestamp': datetime.utcnow().isoformat(),
                'total_characters': len(combined_text),
                'metadata': pdf_info
            }
            
            logging.info(f"Extracted {len(pages_content)} pages from {blob_name}")
            yield document_data
            
        except Exception as e:
            logging.error(f"Error processing PDF {file_path}: {str(e)}", exc_info=True)
            yield {
                'file_path': file_path,
                'error': str(e),
                'processing_timestamp': datetime.utcnow().isoformat(),
                'status': 'failed'
            }

class CustomSemanticChunker(beam.DoFn):
    """
    Simple chunker that uses Vertex AI embeddings
    Fast, straightforward chunking with embedding generation
    """
    
    def __init__(self, project_id: str, region: str, chunk_size: int = 1000, overlap: int = 200):
        self.project_id = project_id
        self.region = region
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.embedding_model = None
    
    def setup(self):
        """Initialize Vertex AI"""
        try:
            print(f"\n{'='*60}")
            print(f"Initializing Vertex AI Chunker")
            print(f"Project: {self.project_id}")
            print(f"Region: {self.region}")
            print(f"{'='*60}\n")
            
            aiplatform.init(project=self.project_id, location=self.region)
            self.embedding_model = TextEmbeddingModel.from_pretrained("text-embedding-004")
            
            print("✓ Vertex AI initialized successfully")
            print("✓ text-embedding-004 model loaded\n")
            
        except Exception as e:
            logging.error(f"Failed to initialize Vertex AI: {e}")
            raise
    
    def simple_chunk_text(self, text: str) -> List[str]:
        """Simple character-based chunking with overlap"""
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            chunk = text[start:end]
            
            if chunk.strip():  # Only add non-empty chunks
                chunks.append(chunk.strip())
            
            start += self.chunk_size - self.overlap
        
        return chunks
    
    def get_embedding(self, text: str) -> List[float]:
        """Get single embedding from Vertex AI"""
        try:
            embeddings = self.embedding_model.get_embeddings([text])
            return embeddings[0].values
        except Exception as e:
            logging.error(f"Error getting embedding: {e}")
            return []
    
    def process(self, document_data: Dict[str, Any]):
        """Process document with simple chunking and embeddings"""
        
        # Skip failed documents
        if document_data.get('status') == 'failed':
            logging.warning(f"Skipping failed document")
            return
        
        file_name = document_data.get('file_name', 'unknown')
        full_text = document_data.get('full_text', '')
        
        print(f"\n{'='*60}")
        print(f"Processing: {file_name}")
        print(f"Document length: {len(full_text):,} characters")
        print(f"{'='*60}\n")
        
        try:
            # Validate document
            if not full_text or len(full_text.strip()) < 50:
                logging.warning(f"Document too short: {file_name}")
                return
            
            # Simple chunking
            print(f"Chunking text (size={self.chunk_size}, overlap={self.overlap})...")
            chunks = self.simple_chunk_text(full_text)
            print(f"✓ Created {len(chunks)} chunks\n")

            batch_embeddings = []
            
            # Process each chunk
            for chunk_idx, chunk_text in enumerate(chunks):
                print(f"Processing chunk {chunk_idx + 1}/{len(chunks)}...")
                
                # Get embedding from Vertex AI
                print(f"  Getting embedding from Vertex AI...")
                embedding = self.get_embedding(chunk_text)
                
                if embedding:
                    print(f"  ✓ Got embedding (dim={len(embedding)})")
                else:
                    print(f"  ✗ Failed to get embedding")
                    embedding = []
                
                # Create chunk data
                chunk_data = {
                    'chunk_id': f"{file_name.replace('.pdf', '')}_{document_data['document_hash'][:8]}_chunk{chunk_idx:04d}",
                    'chunk_index': chunk_idx,
                    'file_name': file_name,
                    'file_path': document_data['file_path'],
                    'document_hash': document_data['document_hash'],
                    'chunk_text': chunk_text,
                    'chunk_length': len(chunk_text),
                    'chunk_word_count': len(chunk_text.split()),
                    'embedding': embedding,
                    'embedding_model': 'text-embedding-004',
                    'has_embedding': len(embedding) > 0,
                    'chunk_type': 'simple_character',
                    'total_chunks': len(chunks),
                    'document_metadata': document_data.get('metadata', {}),
                    'processing_timestamp': datetime.now(UTC).isoformat()
                }
                
                datapoint = {
                    "id": chunk_data['chunk_id'],
                    "embedding": chunk_data['embedding']
                }

                batch_embeddings.append(datapoint)
                yield chunk_data
            
            characters = string.ascii_letters + string.digits
            random_chars = random.choices(characters, k=10)
            upsert_filename = ''.join(random_chars)
            client = storage.Client(project=self.project_id)
            blob = client.bucket("demo-vertex-ai-search").blob(f"dataflow/batch_root/{upsert_filename}.json")

            with blob.open("w", content_type="application/x-ndjson", encoding="utf-8") as f:
                for dt in batch_embeddings:
                    line = json.dumps(dt, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
                    f.write(line)
                    f.write("\n")
            
            #Send completion signal on write completion
            yield pvalue.TaggedOutput("batch_written", "gs://demo-vertex-ai-search/dataflow/batch_root/")

            # #Store chunk batch in GCS for batch upsert
            # gcs_uri = f"gs://demo-vertex-ai-search/dataflow/batch_root/"

            
            print(f"\n✓ Completed processing {file_name}")
            print(f"  Total chunks: {len(chunks)}")
            print(f"{'='*60}\n")
            
        except Exception as e:
            logging.error(f"Error processing {file_name}: {str(e)}", exc_info=True)
            # Yield error chunk
            yield {
                'file_name': file_name,
                'file_path': document_data['file_path'],
                'error': str(e),
                'status': 'failed',
                'processing_timestamp': datetime.now(UTC).isoformat()
            }

class UpsertToVectorSearch(beam.DoFn):
    """Simple upsert to Vertex AI Vector Search"""
    
    def __init__(self, project_id: str, region: str, deployed_index_id: str):
        self.project_id = project_id
        self.region = region
        self.deployed_index_id = deployed_index_id
        self.index = None
    
    def setup(self):
        """Initialize Vector Search endpoint"""
        try:
            print(f"\n{'='*60}")
            print(f"Initializing Vector Search Endpoint")
            print(f"Project: {self.project_id}")
            print(f"Region: {self.region}")
            print(f"Deployment Index ID: {self.deployed_index_id}")
            print(f"{'='*60}\n")
            
            aiplatform.init(project=self.project_id, location=self.region)
            
            index_name = f"projects/{self.project_id}/locations/{self.region}/indexes/{self.deployed_index_id}"
            
            self.index = aiplatform.MatchingEngineIndex(index_name=index_name)

            
            print("✓ Vector Search Index connected\n")
            
        except Exception as e:
            logging.error(f"Failed to initialize Vector Search: {e}")
            raise
    
    def process(self, gcs_batch_prefix: str):
        """Upsert single chunk to vector search"""
        
        try:
            print(f"Upserting: Batch from GCS Bucket")
            
            self.index.update_embeddings(contents_delta_uri=gcs_batch_prefix, is_complete_overwrite=False)

            yield {
                "status": "submitted",
                "contents_delta_uri": gcs_batch_prefix,
                "timestamp": datetime.now(UTC).isoformat(),
            }
   
        except Exception as e:
            logging.error(f"Batch update failed: {e}", exc_info=True)
            yield {
                "status": "failed",
                "error": str(e),
                "contents_delta_uri": gcs_batch_prefix,
                "timestamp": datetime.now(UTC).isoformat(),
            }

class StoreInGCS(beam.DoFn):
    """Simple storage to GCS - one JSON per chunk"""
    
    def __init__(self, staging_bucket: str, project_id: str):
        self.staging_bucket = staging_bucket.replace('gs://', '')
        self.project_id = project_id
        self.storage_client = None
        self.bucket = None
    
    def setup(self):
        """Initialize GCS client"""
        try:
            print(f"\n{'='*60}")
            print(f"Initializing GCS Storage")
            print(f"Bucket: {self.staging_bucket}")
            print(f"{'='*60}\n")
            
            self.storage_client = storage.Client(project=self.project_id)
            self.bucket = self.storage_client.bucket(self.staging_bucket)
            
            print("✓ GCS bucket connected\n")
            
        except Exception as e:
            logging.error(f"Failed to initialize GCS: {e}")
            raise
    
    def process(self, chunk_data: Dict[str, Any]):
        """Store chunk as single JSON file"""
        
        try:
            chunk_id = chunk_data['chunk_id']
            file_name = chunk_data['file_name'].replace('.pdf', '')
            
            print(f"Storing: {chunk_id}")
            
            # Simple path structure
            blob_path = f"processed/{file_name}/{chunk_id}.json"
            
            # Convert embedding to list of floats
            if chunk_data.get('embedding'):
                chunk_data['embedding'] = [float(x) for x in chunk_data['embedding']]
            
            # Store as JSON
            json_str = json.dumps(chunk_data, indent=2, default=str)
            blob = self.bucket.blob(blob_path)
            blob.upload_from_string(json_str, content_type='application/json')
            
            file_url = f"gs://{self.staging_bucket}/{blob_path}"
            print(f"✓ Stored at {file_url}\n")
            
            yield {
                'chunk_id': chunk_id,
                'status': 'success',
                'file_url': file_url,
                'timestamp': datetime.now(UTC).isoformat()
            }
            
        except Exception as e:
            logging.error(f"Error storing {chunk_data.get('chunk_id')}: {e}")
            yield {
                'chunk_id': chunk_data.get('chunk_id'),
                'status': 'failed',
                'error': str(e),
                'timestamp': datetime.now(UTC).isoformat()
            }

def run():
    try:
        """Main pipeline - Flex Template compatible"""
        print("-------------START-1-------------")
        parser = argparse.ArgumentParser()
        parser.add_argument('--input_file', required=True, help='GCS path to input PDF')
        parser.add_argument('--project_id', required=True, help='GCP Project ID')
        parser.add_argument('--region', required=True, help='GCP Region')
        parser.add_argument('--staging_bucket', required=True, help='GCS bucket for staging')
        parser.add_argument('--temp_bucket', required=True, help='GCS bucket for temp files')
        parser.add_argument('--endpoint_id', required=True, help='Vector Search endpoint ID')
        parser.add_argument('--deployed_index_id', required=True, help='Deployed index ID')
        parser.add_argument('--service_account', required=True, help='Service account email')
        parser.add_argument('--min_chunk_size', type=int, default=500, help='Minimum chunk size')
        parser.add_argument('--max_chunk_size', type=int, default=2000, help='Maximum chunk size')
        parser.add_argument('--similarity_threshold', type=float, default=0.75, help='Semantic similarity threshold')
        known_args, pipeline_args = parser.parse_known_args()

        print("-------------START-2-------------")

        print("known_args:", known_args)
        print("pipeline_args:", pipeline_args)
        # Configure pipeline options
        pipeline_options = PipelineOptions(pipeline_args)
        pipeline_options.view_as(GoogleCloudOptions).project = known_args.project_id
        pipeline_options.view_as(GoogleCloudOptions).region = known_args.region
        pipeline_options.view_as(GoogleCloudOptions).staging_location = f"{known_args.temp_bucket}/staging"
        pipeline_options.view_as(GoogleCloudOptions).temp_location = f"{known_args.temp_bucket}/temp"
        pipeline_options.view_as(GoogleCloudOptions).service_account_email = known_args.service_account
        pipeline_options.view_as(StandardOptions).runner = 'DataflowRunner'
        pipeline_options.view_as(WorkerOptions).machine_type = 'n1-standard-4'
        pipeline_options.view_as(WorkerOptions).max_num_workers = 10

        with beam.Pipeline(options=pipeline_options) as pipeline:
            documents = (
                pipeline
                | 'Create Input' >> beam.Create(["gs://demo-vertex-ai-search/Sample-1.pdf"])
                | 'Read PDF' >> beam.ParDo(PDFReader("vertex-ai-search-agent-486817"))
            )

            chunker_outputs = (
                documents
                | 'Semantic Chunking' >> beam.ParDo(
                    CustomSemanticChunker(
                        "vertex-ai-search-agent-486817",
                        "us-central1",
                    )
                ).with_outputs("batch_written", main="chunks")
            )

            chunks = chunker_outputs.chunks
            batch_written = chunker_outputs.batch_written

            storage_results = (
                chunks
                | 'Store in GCS' >> beam.ParDo(
                    StoreInGCS("demo-vertex-ai-search", "vertex-ai-search-agent-486817")
                )
            )

            done = batch_written | "Batch files written (signal)" >> beam.combiners.Count.Globally()

            vector_results = (
                done
                | "Use batch root prefix" >> beam.Map(lambda _: "gs://demo-vertex-ai-search/dataflow/batch_root/")
                | 'Upsert to Vector Search' >> beam.ParDo(
                    UpsertToVectorSearch(
                        "vertex-ai-search-agent-486817",
                        "us-central1",
                        "4941409764388110336",
                    )
                )
            )
    except Exception as e:
            logging.error(f"Error init: {e}")
        
        

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()