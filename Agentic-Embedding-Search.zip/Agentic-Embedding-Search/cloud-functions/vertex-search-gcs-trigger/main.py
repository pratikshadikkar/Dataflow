import functions_framework
from googleapiclient.discovery import build
from datetime import datetime
import os

@functions_framework.cloud_event
def trigger_dataflow_pipeline(cloud_event):
    """
    Triggered by Cloud Storage finalize event.
    Starts a Dataflow job to process the PDF.
    
    Args:
        cloud_event: CloudEvent with storage data
    """
    
    # Extract file information from cloud event
    data = cloud_event.data
    bucket_name = data['bucket']
    file_name = data['name']
    file_path = f"gs://{bucket_name}/{file_name}"
    
    print(f"File uploaded: {file_path}")
    
     # Only process PDF files
    if not file_name.lower().endswith('.pdf'):
        print(f"Skipping non-PDF file: {file_name}")
        return "Skipped: Not a PDF file"
    
     # Get configuration from environment variables
    project_id = os.environ.get('PROJECT_ID')
    region = os.environ.get('REGION', 'us-central1')
    staging_bucket = os.environ.get('STAGING_BUCKET')
    temp_bucket = os.environ.get('TEMP_BUCKET')
    endpoint_id = os.environ.get('ENDPOINT_ID')
    service_account = os.environ.get('SERVICE_ACCOUNT')
    deployed_index_id = os.environ.get('DEPLOYED_INDEX_ID')
    template_path = os.environ.get('TEMPLATE_PATH')
    
    sdk_container_image = f"{region}-docker.pkg.dev/{project_id}/dataflow-templates/pdf-processor:demo123"
    
    # Validate required environment variables
    config = {
        'project_id': project_id,
        'region': region,
        'input_file': file_path,
        'staging_bucket': staging_bucket,
        'temp_bucket': temp_bucket,
        'endpoint_id': endpoint_id,
        'service_account': service_account,
        'deployed_index_id': deployed_index_id,
        'template_path': template_path,
        'sdk_container_image': sdk_container_image,
    }
    print(config)
    print('-----------------------------------------------')
    # Generate unique job name
    timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    safe_filename = file_name.replace('.pdf', '').replace('/', '-').replace('_', '-')[:30]
    job_name = f"pdf-vector-{safe_filename}-{timestamp}".lower()
    
    print(f"Starting Dataflow job: {job_name}")
    print(f"Input file: {file_path}")
    print(f"Project: {project_id}, Region: {region}")
    
    try:
        # Build Dataflow API client
        dataflow = build('dataflow', 'v1b3')
        
        # Launch Dataflow job
        request = dataflow.projects().locations().flexTemplates().launch(
            projectId=project_id,
            location=region,
            body={
                'launchParameter': {
                    'jobName': job_name,
                    'containerSpecGcsPath': template_path,
                    'parameters': config,
                    'environment': {
                        'maxWorkers': 10,
                        'serviceAccountEmail': service_account,
                        'tempLocation': f"{temp_bucket}/temp",
                        'additionalExperiments': ['use_runner_v2'],
                        'subnetwork': 'regions/us-central1/subnetworks/vertex-search-subnet',
                    },
                    
                }
            }
        )
        response = request.execute()
        job_id = response['job']['id']
        
        print(f"Dataflow job started successfully!")
        print(f"Job ID: {job_id}")
        print(f"Job Name: {job_name}")
        print(f"Console: https://console.cloud.google.com/dataflow/jobs/{region}/{job_id}?project={project_id}")
        
        return {
            'status': 'success',
            'job_id': job_id,
            'job_name': job_name,
            'input_file': file_path
        }
        
    except Exception as e:
        error_msg = f"Error starting Dataflow job: {str(e)}"
        print(f"{error_msg}")
        import traceback
        print(traceback.format_exc())
        raise